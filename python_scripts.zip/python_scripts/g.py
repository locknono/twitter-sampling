
import os
import time

dataDays = 1  # 15 + 1
topicNumber = 9
dataPath = '../data/vec/'
ldaDir = dataPath + 'LDA/' + 'alpha=auto/'

docDir= dataPath + 'doc_iter=100_vertor=200/'
vector_size=200
epochs=100
        